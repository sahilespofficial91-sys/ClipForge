plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.clipforge.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clipforge.studio"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
