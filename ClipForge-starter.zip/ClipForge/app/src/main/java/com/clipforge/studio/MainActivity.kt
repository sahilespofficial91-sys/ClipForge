package com.clipforge.studio

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "ClipForge\n\nAndroid recording project starter"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "This starter app is a build-test scaffold. Recording features are not yet implemented."
            textSize = 16f
        }
        val button = Button(this).apply { text = "Project status" }
        button.setOnClickListener { info.text = "APK build scaffold is running. Capture features are not yet implemented." }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
