# ClipForge Android starter

This is a minimal Android project scaffold to test the GitHub Actions APK build path.

**Not a full recorder yet:** screen recording, internal audio capture, pause/resume, and floating controls are not implemented.

## Build with GitHub Actions
1. Upload the contents of this folder to a GitHub repository (keep the `.github/workflows/android.yml` path).
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** (or push to `main`).
4. Open the successful run and download the `app-debug` artifact.
5. Extract the artifact ZIP to obtain `app-debug.apk`.

## Local build
With Android SDK installed and Gradle available, run `gradle assembleDebug`.
